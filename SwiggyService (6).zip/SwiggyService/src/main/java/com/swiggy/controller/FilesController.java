package com.swiggy.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.swiggy.entity.Files;
import com.swiggy.repository.FileRepo;

@RestController
public class FilesController {

	@Autowired
	FileRepo fileRepo;

	@PostMapping("/uploadfile")
	public ResponseEntity<String> insertFile(@RequestParam MultipartFile file) throws IOException {

		Files fis = new Files();
		fis.setFileName(file.getOriginalFilename());
		fis.setFileType(file.getContentType());
		fis.setData(file.getBytes());
		fileRepo.save(fis);
		return ResponseEntity.ok("file upload succesfully:" + file.getOriginalFilename());

	}

	@PostMapping("/uploadmultifiles")
	public ResponseEntity<String> uploadMulti(@RequestParam MultipartFile[] files) throws IOException {

		if (files != null && files.length > 0) {
			for (MultipartFile multipartFile : files) {
				Files fis = new Files();
				fis.setFileName(multipartFile.getOriginalFilename());
				fis.setFileType(multipartFile.getContentType());
				fis.setData(multipartFile.getBytes());
				fileRepo.save(fis);
			}

		}
		return ResponseEntity.ok("multplfiles upload succesfully:");

	}

	@PostMapping("/uploadmultifilesss")
	public ResponseEntity<List<Object>> uploadMultis(@RequestParam MultipartFile[] files) throws IOException {

		List<Object> response = Arrays.stream(files).map(s -> {
			try {
				return insertFile(s);
			} catch (Exception e) {
				return "files uploads error";
			}
		}).collect(Collectors.toList());

		return ResponseEntity.ok(response);

	}

}
