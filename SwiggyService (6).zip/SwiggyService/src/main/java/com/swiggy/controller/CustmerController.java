package com.swiggy.controller;

import java.net.HttpURLConnection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swiggy.entity.Custmer;
import com.swiggy.entity.UserRegister;
import com.swiggy.model.ResponseMessage;
import com.swiggy.service.CustmerService;
import com.swiggy.utility.Constants;

@RestController
public class CustmerController {
	
	@Autowired CustmerService custmerService;


	@PostMapping("/swiggycustmers")
	public ResponseEntity<ResponseMessage>  userRegister(@RequestBody Custmer custmer) {
	   try {
		  if(custmer==null || custmer.getEmail()==null || custmer.getEmail().isEmpty() ||custmer.getName()==null || custmer.getName().isEmpty()) {
		   
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "email and name cant be null"));
   
	   }
		  
		  if(custmer.getId()==null) {
		  Custmer swiggyCustmerss = custmerService.swiggyCustmerss(custmer);
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_OK, Constants.SUCCESS, "swiggy custmets added sucesffully", swiggyCustmerss));
	      }else {
		   Custmer updatedCusmters = custmerService.swiggyCustmerss(custmer);
		   
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "swiggy custmets updated sucesffully", updatedCusmters));
		}
	}catch (Exception e) {
		e.printStackTrace();
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_INTERNAL_ERROR, Constants.FAILURE, "Internal server error"));

	}
	
	
	
	}
	
	
	
	
	
	
}
