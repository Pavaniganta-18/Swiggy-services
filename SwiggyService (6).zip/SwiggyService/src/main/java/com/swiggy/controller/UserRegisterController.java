package com.swiggy.controller;


import java.net.HttpURLConnection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.swiggy.entity.UserRegister;
import com.swiggy.model.ResponseMessage;
import com.swiggy.model.UserReqDTO;
import com.swiggy.model.UserRequestDto;
import com.swiggy.service.UserRegisterService;
import com.swiggy.utility.Constants;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;




@Tag(name = "UserRegisterController ",description = "UserRegister Regsiter and Login, read, update and delete")
@RestController
public class UserRegisterController {
	
	@Autowired
	UserRegisterService userRegisterService;
	
	  @Operation(summary = "Create User Register",description = "e commerece online books store  register the users")
	    @ApiResponses({
	     @ApiResponse(responseCode = "201",description = "user register successfully"),
	     @ApiResponse(responseCode = "400",description = "user register failure"),
	     @ApiResponse(responseCode = "500",description = "Internal server error")
	     })
	@PostMapping("/userregisters")
	public ResponseEntity<ResponseMessage>  userRegister(@RequestBody UserRequestDto userRequestDto) {
	   try {
		  if(userRequestDto==null || userRequestDto.getEmail()==null || userRequestDto.getEmail().isEmpty() ||userRequestDto.getPassword()==null || userRequestDto.getPassword().isEmpty()) {
		   
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "email and password cant be null"));
   
	   }
		 UserRegister registerUsers = userRegisterService.createRegisterUsers(userRequestDto);
		if(registerUsers!=null) {
		
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_OK, Constants.SUCCESS, "swiggy user register sucesffully", registerUsers));
	   }else {
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "swiggy user getting failed", registerUsers));
		}
	}catch (Exception e) {
		e.printStackTrace();
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_INTERNAL_ERROR, Constants.FAILURE, "Internal server error"));

	}
	
	  }
	  @Operation(summary = "get By Swiggy user Id",description = "e commerece online books store  register the users")
	    @ApiResponses({
	     @ApiResponse(responseCode = "201",description = "user register successfully"),
	     @ApiResponse(responseCode = "400",description = "user register failure"),
	     @ApiResponse(responseCode = "500",description = "Internal server error")
	     })	  
@GetMapping("getByUserId/{id}")
public ResponseEntity<ResponseMessage>  getByUser(@PathVariable Long id) {
	//try {
	UserRegister byUsersId = userRegisterService.getByUsersId(id);
	if(byUsersId!=null) {
	
	return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_OK, Constants.SUCCESS, "swiggy user getting succesffully", byUsersId));
}else {
	return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "swiggy user getting failed", byUsersId));
//}//}catch (Exception e) {
	//return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_INTERNAL_ERROR, Constants.FAILURE, "Internal server error"));

}
	  }
	@GetMapping("/getAllSwiggyUsers")
	public ResponseEntity<ResponseMessage>  getAllSwiggyUserss() {
		try {
	 List<UserRegister> allByUsers = userRegisterService.getAllByUsers();
		if(allByUsers!=null) {
		
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_OK, Constants.SUCCESS, "swiggy user getting succesffully", allByUsers));
	}else {
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "swiggy user getting failed", allByUsers));
	}}catch (Exception e) {
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_INTERNAL_ERROR, Constants.FAILURE, "Internal server error"));

	}
	}
		
	@GetMapping("/getSwiggyUsersByID/{id}")
	public UserReqDTO  getUserId(@PathVariable Long id) {
		
		UserReqDTO byUsers = userRegisterService.getByUsers(id);
		
		return byUsers;
	
	}
	
	
	@PostMapping("/login")
	public ResponseEntity<ResponseMessage>  checklogin(@RequestBody UserRequestDto userRequestDto) {
	 
		 UserRegister checkLoginDetails = userRegisterService.checkLoginDetails(userRequestDto);
		if(checkLoginDetails!=null) {
		
		return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_OK, Constants.SUCCESS, "swiggy users Login with successfully", checkLoginDetails));
	   }else {
			return ResponseEntity.ok(new ResponseMessage(HttpURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE, "swiggy user Login failed", checkLoginDetails));
		}
	}
	
	
		
		
		
}
