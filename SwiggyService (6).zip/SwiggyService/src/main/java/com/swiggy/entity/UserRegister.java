package com.swiggy.entity;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table // it is optional
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserRegister {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	
	@Column(name = "firstName")
	private String firstName;
	
	
	@Column(name = "lastName")
	private String lastName;
	

	@NotBlank(message = "Name cannot blank")
	@Schema(description = "email",example = "enter the email")
	@Column(name = "email")
	private String email;
	
	@NotBlank(message = "Name cannot blank")
	@Schema(description = "password",example = "enter the password")
	@Column(name = "password")
	private String password;
	

	@Column(name = "contactId")
	private Long contactId;
	

	


}
