package com.swiggy.serviceImpl;

import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.swiggy.entity.UserRegister;
import com.swiggy.exceptions.ProductIdNotFoundException;
import com.swiggy.model.UserReqDTO;
import com.swiggy.model.UserRequestDto;
import com.swiggy.repository.UserRepo;
import com.swiggy.service.UserRegisterService;

@Service
public class UserRegisterServiceImpl implements UserRegisterService {

	@Autowired
	UserRepo userRepo;

	@Override
	public UserRegister createRegisterUsers(UserRequestDto userRequestDto) {
		UserRegister user = new UserRegister();
		try {
			user.setFirstName(userRequestDto.getFirstName());
			user.setLastName(userRequestDto.getLastName());
			user.setEmail(userRequestDto.getEmail());
			user.setPassword(Base64.getEncoder().encodeToString(userRequestDto.getPassword().getBytes()));
			user.setContactId(userRequestDto.getContactId());
			userRepo.save(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	@Override
	public UserRegister getByUsersId(Long id) {

		Optional<UserRegister> byId = userRepo.findById(id);
		
		if(!byId.isPresent()) {
			
			throw new ProductIdNotFoundException("Product Id Not found");
		}

		return byId.get();

	}

	@Override
	@Cacheable(value = "getAllData")
	public List<UserRegister> getAllByUsers() {
		List<UserRegister> list = userRepo.findAll();
		System.err.println("getting the Data from Database");

		return list;
	}

	@Override
	public UserReqDTO getByUsers(Long id) {

		Optional<UserRegister> byId = userRepo.findById(id);

		UserRegister userRegister = byId.get();

		return new UserReqDTO(userRegister.getFirstName(), userRegister.getLastName(), userRegister.getEmail());

	}

	@Override
	public UserRegister checkLoginDetails(UserRequestDto userRequestDto) {

		UserRegister byEmail = userRepo.findByEmail(userRequestDto.getEmail());

		if (byEmail != null) {

			String decode = new String(Base64.getDecoder().decode(byEmail.getPassword()));

			if (decode.equals(userRequestDto.getPassword())) {

				return byEmail;
			}

		}

		return null;

	}

}
