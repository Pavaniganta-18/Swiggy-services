package com.swiggy.serviceImpl;

import java.util.Optional;

import javax.management.RuntimeErrorException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.swiggy.entity.Custmer;
import com.swiggy.repository.CustmerRepo;
import com.swiggy.service.CustmerService;

@Service
public class CustmerServiceImpl implements CustmerService {

	@Autowired
	CustmerRepo custmerRepo;

	@Override
	public Custmer swiggyCustmerss(Custmer custmer) {

		if (custmer.getId() == null) {

			custmerRepo.save(custmer);

		} else {

			Optional<Custmer> byId = custmerRepo.findById(custmer.getId());

			if (byId.isPresent()) {

				Custmer existData = byId.get();
				existData.setName(custmer.getName());
				existData.setEmail(custmer.getEmail());
				custmerRepo.save(existData);

			} else {

				throw new RuntimeException("Custmer Id Not Found");
			}

		}

		return custmer;
	}

}
