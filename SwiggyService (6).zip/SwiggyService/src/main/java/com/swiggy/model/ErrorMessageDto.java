package com.swiggy.model;

import java.util.List;

import lombok.Data;

@Data
public class ErrorMessageDto {

	private Integer statusCode;
	private String status;
	private String message;
	private List<?> list;
	
	public ErrorMessageDto(Integer statusCode, String status, String message, List<?> list) {
		super();
		this.statusCode = statusCode;
		this.status = status;
		this.message = message;
		this.list = list;
	}

}
