package com.swiggy.utility;

public class Constants {

	public static final String SUCCESS ="success";
	public static final String FAILURE ="failure";
	public static final String FAILED ="failed";
	
	
}
