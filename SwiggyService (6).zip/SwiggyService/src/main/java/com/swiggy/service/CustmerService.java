package com.swiggy.service;

import com.swiggy.entity.Custmer;

public interface CustmerService {

	public Custmer swiggyCustmerss(Custmer custmer);

}
