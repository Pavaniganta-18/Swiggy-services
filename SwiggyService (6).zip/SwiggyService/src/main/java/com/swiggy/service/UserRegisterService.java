package com.swiggy.service;

import java.util.List;

import com.swiggy.entity.UserRegister;
import com.swiggy.model.UserReqDTO;
import com.swiggy.model.UserRequestDto;

public interface UserRegisterService {

	public UserRegister createRegisterUsers(UserRequestDto userRequestDto);

	public UserRegister getByUsersId(Long id);

	public List<UserRegister> getAllByUsers();

	public UserReqDTO getByUsers(Long id);

	public UserRegister checkLoginDetails(UserRequestDto userRequestDto);


	


}
