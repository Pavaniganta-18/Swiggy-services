package com.swiggy.exceptions;

import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.swiggy.model.ErrorMessageDto;
import com.swiggy.utility.Constants;

@ControllerAdvice
public class RestGlobalExceptionController {

	@ExceptionHandler(ProductIdNotFoundException.class)
	public ResponseEntity<Object> handleGlobalExceptions(ProductIdNotFoundException px) {
		List<String> list = new ArrayList<>();
//		list.add("ErrorMessage : product Id Not Found");
		list.add("Detailed Message:" + px.getLocalizedMessage());
		list.add("Timestamp" + System.currentTimeMillis());
		ErrorMessageDto err = new ErrorMessageDto(HttpsURLConnection.HTTP_BAD_REQUEST, Constants.FAILURE,
				"PRODUCT-NOTFOUND", list);
		return ResponseEntity.ok(err);

	}

	
}
