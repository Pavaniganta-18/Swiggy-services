package com.swiggy.exceptions;

public class ProductIdNotFoundException extends RuntimeException {
	
	public ProductIdNotFoundException(String msg) {
		
		super(msg);
		
	}
	
	

}
