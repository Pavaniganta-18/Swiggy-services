package com.swiggy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.swiggy.entity.UserRegister;

@Repository
public interface UserRepo extends JpaRepository<UserRegister,Long>{

//@Query(value ="select * from user_register where email = :email AND password = :password",nativeQuery = true)
//@Query(value ="select u from UserRegister where email = :email AND password = :password")
 //public UserRegister findByUsernameAndPassword(@Param("email") String email,@Param("password") String password);

public UserRegister findByEmail(String email);

	

}
